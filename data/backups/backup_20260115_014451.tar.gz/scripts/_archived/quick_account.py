#!/usr/bin/env python3
"""Quick account check for km:US500 - uses single Info object."""

from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants
import time

WALLET = "0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C"

print("=" * 60)
print("km:US500 ACCOUNT CHECK")
print("=" * 60)

# Use single Info with km perp_dexs
info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])

# 1. Open orders
orders = info.open_orders(WALLET)
print(f"\nOpen Orders: {len(orders)}")
by_coin = {}
for o in orders:
    coin = o.get("coin", "?")
    by_coin[coin] = by_coin.get(coin, 0) + 1
for coin, count in sorted(by_coin.items(), key=lambda x: -x[1])[:5]:
    print(f"  {coin}: {count}")

# 2. Spot USDH
spot = info.spot_user_state(WALLET)
usdh_total = 0
usdh_hold = 0
for b in spot.get("balances", []):
    if b.get("coin") == "USDH":
        usdh_total = float(b.get("total", 0))
        usdh_hold = float(b.get("hold", 0))
        break

print(f"\nUSDH Balance:")
print(f"  Total: ${usdh_total:.2f}")
print(f"  Hold: ${usdh_hold:.2f}")
print(f"  Available: ${usdh_total - usdh_hold:.2f}")

# 3. User state (with km perp_dexs)
state = info.user_state(WALLET)
margin = state.get("marginSummary", {})
print(f"\nKM Margin Summary:")
print(f"  Account Value: ${float(margin.get('accountValue', 0)):.2f}")
print(f"  Margin Used: ${float(margin.get('totalMarginUsed', 0)):.2f}")

# Positions
positions = state.get("assetPositions", [])
active = [p for p in positions if float(p.get("position", {}).get("szi", 0)) != 0]
print(f"\nActive Positions: {len(active)}")
for p in active:
    pos = p.get("position", {})
    print(f"  {pos.get('coin')}: {pos.get('szi')} @ {pos.get('entryPx')}, margin={pos.get('marginUsed')}")

# 4. Recent fills
now = int(time.time() * 1000)
hour_ago = now - (1 * 60 * 60 * 1000)
fills = info.user_fills_by_time(WALLET, hour_ago, now)
km_fills = [f for f in fills if "km:" in f.get("coin", "")]
print(f"\nFills last hour: {len(km_fills)}")

print("\n" + "=" * 60)
print(f"TRADING EQUITY (USDH): ${usdh_total:.2f}")
print("=" * 60)
