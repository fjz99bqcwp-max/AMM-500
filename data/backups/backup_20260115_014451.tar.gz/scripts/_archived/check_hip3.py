#!/usr/bin/env python3
"""Check HIP-3 perp deployer user state for km:US500."""

import requests
import json

wallet = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Check for perp deployer user state (HIP-3)
print('=== PERP DEPLOYER USER STATE ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'perpDeployerUserState', 'user': wallet, 'perpDex': 'km'},
        timeout=10
    )
    print(f'Status: {response.status_code}')
    print(f'Response: {response.text[:2000]}')
except Exception as e:
    print(f'Exception: {e}')

# Check for user funding history (might show transfers to isolated)
print('\n=== USER FUNDING HISTORY ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'userFunding', 'user': wallet, 'startTime': 0, 'endTime': 9999999999999},
        timeout=10
    )
    print(f'Status: {response.status_code}')
    if response.status_code == 200:
        data = response.json()
        print(f'Funding entries: {len(data) if isinstance(data, list) else "N/A"}')
        if isinstance(data, list):
            for f in data[:10]:
                print(f'  {f}')
    else:
        print(f'Error: {response.text[:500]}')
except Exception as e:
    print(f'Exception: {e}')

# Try using the SDK with perp_dexs
print('\n=== SDK WITH PERP_DEXS ===')
try:
    from hyperliquid.info import Info
    from hyperliquid.utils import constants
    
    info = Info(constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
    
    # Get user state through SDK with perp_dexs
    state = info.user_state(wallet)
    print(f'User state: {json.dumps(state, indent=2)[:2000]}')
    
except Exception as e:
    print(f'Exception: {e}')

# Check open orders specifically for km:US500
print('\n=== OPEN ORDERS (km:US500) ===')
try:
    from hyperliquid.info import Info
    from hyperliquid.utils import constants
    
    info = Info(constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
    orders = info.open_orders(wallet)
    print(f'Total orders: {len(orders)}')
    for o in orders:
        print(f'  {o}')
except Exception as e:
    print(f'Exception: {e}')

# Check user fills for km assets specifically
print('\n=== USER FILLS (km assets) ===')
try:
    from hyperliquid.info import Info
    from hyperliquid.utils import constants
    
    info = Info(constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
    from datetime import datetime, timedelta
    now = int(datetime.now().timestamp() * 1000)
    week_ago = int((datetime.now() - timedelta(days=7)).timestamp() * 1000)
    
    fills = info.user_fills_by_time(wallet, week_ago, now)
    print(f'Total fills: {len(fills) if fills else 0}')
    if fills:
        km_fills = [f for f in fills if 'km:' in f.get('coin', '')]
        print(f'KM fills: {len(km_fills)}')
        for f in km_fills[:10]:
            print(f'  {f.get("coin")} {f.get("side")} {f.get("sz")} @ {f.get("px")}')
except Exception as e:
    print(f'Exception: {e}')
