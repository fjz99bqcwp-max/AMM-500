#!/usr/bin/env python3
"""Check USDH-based isolated margin for km:US500."""

import requests
import json

wallet = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Get spot USDH balance
print('=== SPOT USDH BALANCE ===')
response = requests.post(
    'https://api.hyperliquid.xyz/info',
    headers={'Content-Type': 'application/json'},
    json={'type': 'spotClearinghouseState', 'user': wallet},
    timeout=10
)
spot = response.json()
for b in spot.get('balances', []):
    if b.get('coin') == 'USDH':
        print(f"USDH Total: ${float(b['total']):.2f}")
        print(f"USDH Hold: ${float(b['hold']):.2f}")
        print(f"USDH Available: ${float(b['total']) - float(b['hold']):.2f}")

# Try to get perp state for km deployer specifically
print('\n=== KM PERP USER STATE ===')
# The SDK with perp_dexs=['km'] should return km positions
from hyperliquid.info import Info
from hyperliquid.utils import constants

info = Info(constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])

# Check if there's a separate clearinghouse for km
# Try clearinghouseState which may include km positions
response = requests.post(
    'https://api.hyperliquid.xyz/info',
    headers={'Content-Type': 'application/json'},
    json={'type': 'clearinghouseState', 'user': wallet},
    timeout=10
)
ch_state = response.json()
print(f"Cross-margin account value: ${float(ch_state.get('marginSummary', {}).get('accountValue', 0)):.4f}")
print(f"Asset positions: {len(ch_state.get('assetPositions', []))}")

# The km:US500 position might be in a different user state
# Try with perpDex parameter
print('\n=== KM SPECIFIC CLEARINGHOUSE STATE ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'clearinghouseState', 'user': wallet, 'perpDex': 'km'},
        timeout=10
    )
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(json.dumps(data, indent=2)[:2000])
except Exception as e:
    print(f"Error: {e}")

# Check user fills to see recent km:US500 activity
print('\n=== RECENT km:US500 FILLS ===')
from datetime import datetime, timedelta
fills = info.user_fills_by_time(
    wallet,
    int((datetime.now() - timedelta(hours=24)).timestamp() * 1000),
    int(datetime.now().timestamp() * 1000)
)
km_fills = [f for f in fills if 'km:US500' in f.get('coin', '')]
print(f"km:US500 fills in last 24h: {len(km_fills)}")
if km_fills:
    for f in km_fills[:5]:
        print(f"  {f.get('side')} {f.get('sz')} @ {f.get('px')} | fee: {f.get('fee')} | pnl: {f.get('closedPnl', 0)}")

# Check open orders for km:US500
print('\n=== OPEN ORDERS km:US500 ===')
orders = info.open_orders(wallet)
km_orders = [o for o in orders if 'km:US500' in o.get('coin', '')]
print(f"km:US500 orders: {len(km_orders)}")
for o in km_orders[:5]:
    print(f"  {o}")

# Try to get the position via user_state with perp_dexs
print('\n=== USER STATE VIA SDK WITH PERP_DEXS ===')
state = info.user_state(wallet)
print(f"Asset positions count: {len(state.get('assetPositions', []))}")
for pos in state.get('assetPositions', []):
    print(f"  Position: {pos}")
