#!/usr/bin/env python3
"""Cancel ALL open orders for km:US500 - fetches from exchange directly."""

from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants as hl_constants
from hyperliquid.utils.signing import CancelRequest
from eth_account import Account
import os
from dotenv import load_dotenv
from pathlib import Path

# Load config
load_dotenv(Path("/Users/nheosdisplay/VSC/AMM/AMM-500/config/.env"))

MAIN_WALLET = os.getenv("WALLET_ADDRESS")
PRIVATE_KEY = os.getenv("PRIVATE_KEY")

print(f"Main wallet: {MAIN_WALLET[:10]}...")

# Initialize
wallet = Account.from_key(PRIVATE_KEY)
print(f"API wallet: {wallet.address[:10]}...")

info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
exchange = Exchange(wallet, hl_constants.MAINNET_API_URL, account_address=MAIN_WALLET, perp_dexs=['km'])

# Get ALL open orders from exchange
print("\nFetching open orders from exchange...")
orders = info.open_orders(MAIN_WALLET)
print(f"Total open orders: {len(orders)}")

# Filter km:US500 orders
km_orders = [o for o in orders if 'km:' in o.get('coin', '') or o.get('coin') == 'US500']
print(f"km:US500 orders: {len(km_orders)}")

if not km_orders:
    print("No km:US500 orders to cancel!")
    exit(0)

# Show some orders
print("\nSample orders:")
for o in km_orders[:5]:
    print(f"  {o.get('coin')}: {o.get('side')} {o.get('sz')} @ {o.get('limitPx')} (oid={o.get('oid')})")

# Build cancel requests
cancel_requests = []
for o in km_orders:
    coin = o.get('coin')
    oid = o.get('oid')
    if coin and oid:
        cancel_requests.append(CancelRequest(coin=coin, oid=int(oid)))

print(f"\nCancelling {len(cancel_requests)} orders...")

# Cancel in batches of 50
batch_size = 50
cancelled = 0
for i in range(0, len(cancel_requests), batch_size):
    batch = cancel_requests[i:i+batch_size]
    try:
        result = exchange.bulk_cancel(batch)
        print(f"Batch {i//batch_size + 1}: {result}")
        cancelled += len(batch)
    except Exception as e:
        print(f"Batch {i//batch_size + 1} error: {e}")

print(f"\nCancelled {cancelled} orders")

# Verify
print("\nVerifying...")
orders_after = info.open_orders(MAIN_WALLET)
km_after = [o for o in orders_after if 'km:' in o.get('coin', '')]
print(f"km:US500 orders remaining: {len(km_after)}")
