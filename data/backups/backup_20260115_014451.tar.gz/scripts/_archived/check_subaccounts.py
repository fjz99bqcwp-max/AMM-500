#!/usr/bin/env python3
"""Check for sub-accounts on Hyperliquid."""

from hyperliquid.info import Info
from hyperliquid.utils import constants
from dotenv import load_dotenv
from pathlib import Path
import os
import json
import requests

load_dotenv(Path(__file__).parent.parent / 'config' / '.env')
wallet = os.getenv('WALLET_ADDRESS')
print(f'Wallet: {wallet}')

info = Info(constants.MAINNET_API_URL, skip_ws=True)

# Direct API call to check sub-accounts
print('\n=== CHECKING SUB-ACCOUNTS ===')
try:
    response = requests.post(
        "https://api.hyperliquid.xyz/info",
        headers={"Content-Type": "application/json"},
        json={"type": "subAccounts", "user": wallet}
    )
    data = response.json()
    print(f"Sub-accounts: {json.dumps(data, indent=2)}")
except Exception as e:
    print(f"Error: {e}")

# Check clearinghouse state
print('\n=== CLEARINGHOUSE STATE ===')
try:
    response = requests.post(
        "https://api.hyperliquid.xyz/info",
        headers={"Content-Type": "application/json"},
        json={"type": "clearinghouseState", "user": wallet}
    )
    data = response.json()
    print(json.dumps(data, indent=2)[:2000])
except Exception as e:
    print(f"Error: {e}")

# Check if there's a perp user state for US500 specifically
print('\n=== PERP USER STATE (for km:US500) ===')
try:
    # Get perpetuals meta to find US500 asset index
    response = requests.post(
        "https://api.hyperliquid.xyz/info",
        headers={"Content-Type": "application/json"},
        json={"type": "perpMeta", "user": wallet}
    )
    print(f"Perp meta response: {response.text[:500]}")
except Exception as e:
    print(f"Error: {e}")

# Check open orders - this might show us the correct account
print('\n=== OPEN ORDERS ===')
orders = info.open_orders(wallet)
print(f"Open orders: {len(orders)}")
for o in orders[:5]:
    print(f"  {o}")

# Check user fills
print('\n=== RECENT FILLS ===')
from datetime import datetime, timedelta
now = int(datetime.now().timestamp() * 1000)
day_ago = int((datetime.now() - timedelta(days=7)).timestamp() * 1000)
fills = info.user_fills_by_time(wallet, day_ago, now)
print(f"Fills in last 7 days: {len(fills) if fills else 0}")
if fills:
    for f in fills[:5]:
        print(f"  {f.get('coin')} {f.get('side')} {f.get('sz')} @ {f.get('px')}")
