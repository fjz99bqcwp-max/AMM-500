#!/usr/bin/env python3
"""Deep check for orders on all possible addresses."""

import requests

MAIN = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'
API = '0x02E02FBC90a195BF82dDc4d43FAfd8449B518805'

def check_orders(address, name):
    print(f"\n=== {name}: {address} ===")
    
    # openOrders
    resp = requests.post('https://api.hyperliquid.xyz/info', 
                        json={'type': 'openOrders', 'user': address}, timeout=10)
    orders = resp.json()
    print(f"openOrders: {len(orders)}")
    
    # Filter for km:US500
    km_orders = [o for o in orders if 'US500' in o.get('coin', '')]
    if km_orders:
        print(f"km:US500 orders: {len(km_orders)}")
        for o in km_orders[:5]:
            print(f"  {o['coin']}: {o['side']} {o['sz']} @ {o['limitPx']} (oid={o['oid']})")
    
    # frontendOpenOrders
    resp = requests.post('https://api.hyperliquid.xyz/info', 
                        json={'type': 'frontendOpenOrders', 'user': address}, timeout=10)
    frontend = resp.json()
    print(f"frontendOpenOrders: {len(frontend)}")
    
    return len(orders), len(km_orders) if km_orders else 0

# Check both wallets
main_total, main_km = check_orders(MAIN, "Main Wallet")
api_total, api_km = check_orders(API, "API Wallet")

print(f"\n=== Summary ===")
print(f"Main wallet: {main_total} total, {main_km} km:US500")
print(f"API wallet: {api_total} total, {api_km} km:US500")

# If still 0, the 325 orders might have expired or be on a different address
if main_km == 0 and api_km == 0:
    print("\nNo orders found via API. Orders may have:")
    print("  - Expired or been filled")
    print("  - UI showing cached/stale data (try refreshing)")
    print("  - Be on a different sub-account")
