#!/usr/bin/env python3
"""Emergency cancel ALL km:US500 orders."""

from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants as hl_constants
from hyperliquid.utils.signing import CancelRequest
from eth_account import Account
import os
from dotenv import load_dotenv

load_dotenv('config/.env')

MAIN = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'
pk = os.getenv('PRIVATE_KEY')
wallet = Account.from_key(pk)

print('Fetching all orders...')
info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
orders = info.open_orders(MAIN)
print(f'Total orders: {len(orders)}')

km_orders = [o for o in orders if o.get('coin') == 'km:US500']
print(f'km:US500 orders: {len(km_orders)}')

if km_orders:
    print('\nCancelling all km:US500 orders...')
    exchange = Exchange(wallet, hl_constants.MAINNET_API_URL, account_address=MAIN, perp_dexs=['km'])
    
    cancel_reqs = [CancelRequest(coin='km:US500', oid=int(o['oid'])) for o in km_orders]
    
    # Cancel in batches of 40
    batch_size = 40
    total_cancelled = 0
    for i in range(0, len(cancel_reqs), batch_size):
        batch = cancel_reqs[i:i+batch_size]
        result = exchange.bulk_cancel(batch)
        status = result.get('status', 'unknown')
        print(f'Batch {i//batch_size + 1}: {status} ({len(batch)} orders)')
        total_cancelled += len(batch)
    
    print(f'\nCancelled {total_cancelled} orders')
    
    # Verify
    print('\nVerifying...')
    orders_after = info.open_orders(MAIN)
    km_after = [o for o in orders_after if o.get('coin') == 'km:US500']
    print(f'Remaining km:US500 orders: {len(km_after)}')
else:
    print('No km:US500 orders to cancel')
