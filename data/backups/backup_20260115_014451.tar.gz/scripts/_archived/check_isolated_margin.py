#!/usr/bin/env python3
"""Check km:US500 isolated margin structure."""

import sys
sys.path.insert(0, "/Users/nheosdisplay/VSC/AMM/AMM-500")

from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants

WALLET = "0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C"

info = Info(hl_constants.MAINNET_API_URL)

print("=" * 60)
print("CHECKING km:US500 ISOLATED MARGIN STRUCTURE")
print("=" * 60)

# 1. Spot USDH
spot = info.spot_user_state(WALLET)
usdh_balance = 0
for b in spot.get("balances", []):
    if b.get("coin") == "USDH":
        usdh_balance = float(b.get("total", 0))
        usdh_hold = float(b.get("hold", 0))
        print(f"\nSpot USDH: Total=${usdh_balance:.2f}, Hold=${usdh_hold:.2f}, Available=${usdh_balance - usdh_hold:.2f}")
        break
else:
    print("\nNo Spot USDH balance found")

# 2. Cross-margin perp state (for comparison)
cross_state = info.user_state(WALLET)
cross_margin = cross_state.get("marginSummary", {})
print(f"\nCross-margin perp: AccountValue=${float(cross_margin.get('accountValue', 0)):.4f}")

# 3. Check all HIP-3 perp states using perp_dexs
print("\n--- HIP-3 Perp States (perp_dexs=['km']) ---")
try:
    km_state = info.user_state(WALLET, perp_dexs=["km"])
    km_margin = km_state.get("marginSummary", {})
    print(f"KM perp AccountValue: ${float(km_margin.get('accountValue', 0)):.2f}")
    print(f"KM perp Withdrawable: ${float(km_margin.get('withdrawable', 0)):.2f}")
    print(f"KM perp TotalMarginUsed: ${float(km_margin.get('totalMarginUsed', 0)):.2f}")
    print(f"KM perp TotalNtlPos: ${float(km_margin.get('totalNtlPos', 0)):.2f}")
    print(f"Full marginSummary: {km_margin}")
    
    # Check positions in km state
    km_positions = km_state.get("assetPositions", [])
    if km_positions:
        print(f"\nKM Positions ({len(km_positions)}):")
        for pos in km_positions:
            p = pos.get("position", {})
            coin = p.get("coin", "?")
            size = float(p.get("szi", 0))
            entry = float(p.get("entryPx", 0))
            margin = float(p.get("marginUsed", 0))
            unreal_pnl = float(p.get("unrealizedPnl", 0))
            leverage = p.get("leverage", {})
            lev_type = leverage.get("type", "?")
            lev_val = leverage.get("value", 0)
            print(f"  {coin}: size={size:.4f}, entry=${entry:.2f}, margin=${margin:.2f}, uPnL=${unreal_pnl:.2f}")
            print(f"    leverage: type={lev_type}, value={lev_val}")
    else:
        print("\nNo km positions found")
except Exception as e:
    print(f"Error querying km state: {e}")

# 4. Total equity for trading
print("\n" + "=" * 60)
print("TOTAL EQUITY FOR km:US500 TRADING")
print("=" * 60)

# For isolated margin, the tradeable equity is:
# - Spot USDH available (for new positions)
# - Position margin is already committed to existing positions
# Total "account value" = Spot USDH + margin in positions + unrealized PnL

# But for ORDER SIZING, we use available Spot USDH
print(f"\nSpot USDH Available: ${usdh_balance - usdh_hold:.2f}")
print("(This is what can be used for NEW position margin)")

# Check if km perp state shows USDH balance too
try:
    km_state = info.user_state(WALLET, perp_dexs=["km"])
    km_equity = float(km_state.get("marginSummary", {}).get("accountValue", 0))
    print(f"\nKM Perp AccountValue: ${km_equity:.2f}")
    print("(This should reflect USDH equity for isolated km positions)")
except:
    pass
