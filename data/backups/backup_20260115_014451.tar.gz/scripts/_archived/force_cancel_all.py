#!/usr/bin/env python3
"""
Force cancel ALL km:US500 orders using direct API.
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
from dotenv import load_dotenv

# Load config
load_dotenv('config/.env')

MAIN_WALLET = os.getenv('WALLET_ADDRESS', '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C')
PRIVATE_KEY = os.getenv('PRIVATE_KEY')

print(f"=== Force Cancel All km:US500 Orders ===")
print(f"Main wallet: {MAIN_WALLET}")

# Get all open orders
resp = requests.post("https://api.hyperliquid.xyz/info", json={
    "type": "openOrders",
    "user": MAIN_WALLET
}, timeout=10)
all_orders = resp.json()

print(f"\nTotal open orders: {len(all_orders)}")

# Filter for km:US500
km_orders = [o for o in all_orders if o.get('coin') in ['km:US500', 'US500']]
print(f"km:US500 orders: {len(km_orders)}")

if not km_orders:
    print("\nNo km:US500 orders to cancel!")
    sys.exit(0)

# Show sample
print("\nSample orders:")
for o in km_orders[:5]:
    print(f"  OID: {o.get('oid')}, Side: {o.get('side')}, Price: {o.get('limitPx')}, Size: {o.get('sz')}")

# Use SDK to cancel
print("\n--- Cancelling via SDK ---")
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils.signing import CancelRequest
from eth_account import Account

wallet = Account.from_key(PRIVATE_KEY)
derived_address = wallet.address.lower()
configured_address = MAIN_WALLET.lower()

print(f"Derived address: {derived_address}")
print(f"Configured address: {configured_address}")

# Initialize exchange
if derived_address != configured_address:
    print("Using API wallet mode")
    exchange = Exchange(
        wallet=wallet,
        base_url="https://api.hyperliquid.xyz",
        account_address=MAIN_WALLET,
        perp_dexs=['km'],
    )
else:
    exchange = Exchange(
        wallet=wallet,
        base_url="https://api.hyperliquid.xyz",
        perp_dexs=['km'],
    )

# Build cancel requests
cancel_requests = [
    CancelRequest(coin='km:US500', oid=int(o.get('oid')))
    for o in km_orders
]

print(f"\nCancelling {len(cancel_requests)} orders...")
result = exchange.bulk_cancel(cancel_requests)
print(f"Result: {result}")

# Verify
print("\n--- Verification ---")
resp2 = requests.post("https://api.hyperliquid.xyz/info", json={
    "type": "openOrders",
    "user": MAIN_WALLET
}, timeout=10)
remaining = [o for o in resp2.json() if o.get('coin') in ['km:US500', 'US500']]
print(f"Remaining km:US500 orders: {len(remaining)}")

if remaining:
    print("WARNING: Some orders still open!")
    for o in remaining[:5]:
        print(f"  OID: {o.get('oid')}")
else:
    print("SUCCESS: All orders cancelled!")
