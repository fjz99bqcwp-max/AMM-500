#!/usr/bin/env python3
"""Analyze km:US500 trading PnL."""

from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants
import time
from collections import defaultdict

WALLET = "0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C"
info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])

# Last 24h fills
now = int(time.time() * 1000)
day_ago = now - (24 * 60 * 60 * 1000)
fills = info.user_fills_by_time(WALLET, day_ago, now)

km_fills = [f for f in fills if 'km:' in f.get('coin', '')]
print(f'km:US500 fills in last 24h: {len(km_fills)}')

total_pnl = sum(float(f.get('closedPnl', 0)) for f in km_fills)
total_fee = sum(float(f.get('fee', 0)) for f in km_fills)
print(f'Total closed PnL: ${total_pnl:.2f}')
print(f'Total fees: ${total_fee:.2f}')
print(f'Net P&L: ${total_pnl - total_fee:.2f}')

# Breakdown by hour
by_hour = defaultdict(lambda: {'pnl': 0, 'fee': 0, 'count': 0})
for f in km_fills:
    ts = f.get('time', 0)
    hour = int(ts / (3600 * 1000)) % 24
    by_hour[hour]['pnl'] += float(f.get('closedPnl', 0))
    by_hour[hour]['fee'] += float(f.get('fee', 0))
    by_hour[hour]['count'] += 1

print('\nBy hour (UTC):')
for h in sorted(by_hour.keys()):
    d = by_hour[h]
    net = d['pnl'] - d['fee']
    print(f'  Hour {h:02d}: {d["count"]:4d} fills, PnL ${d["pnl"]:+.2f}, Fee ${d["fee"]:.2f}, Net ${net:+.2f}')
