#!/usr/bin/env python3
"""Deep check of KM state."""

import requests
from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants

MAIN = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Check spot balances (USDH)
resp = requests.post('https://api.hyperliquid.xyz/info', json={'type': 'spotClearinghouseState', 'user': MAIN}, timeout=10)
spot = resp.json()
print('=== Spot State ===')
for b in spot.get('balances', []):
    print(f'  {b}')

# Use SDK with perp_dexs for KM
print('\n=== SDK Info with perp_dexs=["km"] ===')
info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])

# user_state
user_state = info.user_state(MAIN)
print(f'marginSummary: {user_state.get("marginSummary")}')
positions = user_state.get('assetPositions', [])
print(f'positions ({len(positions)}):')
for p in positions:
    pos = p.get('position', {})
    print(f'  {pos.get("coin")}: size={pos.get("szi")}, value={pos.get("positionValue")}')

# open_orders
orders = info.open_orders(MAIN)
print(f'\nopen_orders: {len(orders)}')
for o in orders[:20]:
    print(f'  {o.get("coin")}: {o.get("side")} {o.get("sz")} @ {o.get("limitPx")} (oid={o.get("oid")})')

# All open orders (frontend)
print('\n=== Frontend Open Orders (direct API) ===')
resp = requests.post('https://api.hyperliquid.xyz/info', json={'type': 'frontendOpenOrders', 'user': MAIN}, timeout=10)
frontend = resp.json()
print(f'frontendOpenOrders: {len(frontend)}')
for o in frontend[:10]:
    print(f'  {o}')
