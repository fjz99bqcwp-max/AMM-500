#!/usr/bin/env python3
"""Check for isolated margin and KM deployer state."""

import requests
import json

wallet = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Check perp metas (plural) for KM assets
print('=== CHECKING PERP METAS ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'perpMetas'},
        timeout=10
    )
    print(f'Status: {response.status_code}')
    if response.status_code == 200:
        data = response.json()
        print(json.dumps(data, indent=2)[:2000])
    else:
        print(f'Error: {response.text}')
except Exception as e:
    print(f'Exception: {e}')

# Check all metas
print('\n=== ALL METAS ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'allMetas'},
        timeout=10
    )
    if response.status_code == 200:
        data = response.json()
        # Check if KM metas are included
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and 'universe' in item:
                    universe = item['universe']
                    print(f"Found universe with {len(universe)} assets")
                    for asset in universe:
                        name = asset.get('name', '')
                        if 'US500' in name or 'km' in name.lower():
                            print(f"  Found: {name} -> {asset}")
        else:
            print(json.dumps(data, indent=2)[:1500])
    else:
        print(f'Error: {response.text}')
except Exception as e:
    print(f'Exception: {e}')

# Check user fills for US500 specifically
print('\n=== USER FILLS (all coins) ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'userFillsByTime', 'user': wallet, 'startTime': 0, 'endTime': 9999999999999},
        timeout=10
    )
    if response.status_code == 200:
        fills = response.json()
        if fills:
            print(f'Total fills: {len(fills)}')
            # Group by coin
            coins = {}
            for f in fills:
                coin = f.get('coin', 'unknown')
                coins[coin] = coins.get(coin, 0) + 1
            print(f'Coins traded: {coins}')
            # Show last 5 fills
            for f in fills[:5]:
                print(f"  {f.get('coin')} {f.get('side')} {f.get('sz')} @ {f.get('px')}")
        else:
            print('No fills found')
    else:
        print(f'Error: {response.text}')
except Exception as e:
    print(f'Exception: {e}')
