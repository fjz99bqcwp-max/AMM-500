#!/usr/bin/env python3
"""Check KM orders using different API methods."""

import requests
from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants

MAIN = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'
API = '0x02E02FBC90a195BF82dDc4d43FAfd8449B518805'

def main():
    print("=== Checking for KM perp orders ===\n")
    
    # Direct API: openOrders
    resp = requests.post(
        'https://api.hyperliquid.xyz/info',
        json={'type': 'openOrders', 'user': MAIN},
        timeout=10
    )
    orders = resp.json()
    print(f"openOrders (MAIN): {len(orders)}")
    
    # Direct API: frontendOpenOrders
    resp = requests.post(
        'https://api.hyperliquid.xyz/info', 
        json={'type': 'frontendOpenOrders', 'user': MAIN},
        timeout=10
    )
    frontend_orders = resp.json()
    print(f"frontendOpenOrders (MAIN): {len(frontend_orders)}")
    
    # clearinghouseState for positions
    resp = requests.post(
        'https://api.hyperliquid.xyz/info',
        json={'type': 'clearinghouseState', 'user': MAIN},
        timeout=10
    )
    state = resp.json()
    positions = state.get('assetPositions', [])
    print(f"assetPositions: {len(positions)}")
    for p in positions:
        pos = p.get('position', {})
        coin = pos.get('coin', 'unknown')
        sz = pos.get('szi', '0')
        print(f"  {coin}: {sz}")
    
    # Using SDK Info with perp_dexs
    print("\n=== SDK Info with perp_dexs=['km'] ===")
    info = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
    sdk_orders = info.open_orders(MAIN)
    print(f"SDK open_orders: {len(sdk_orders)}")
    
    # Show any orders
    for o in sdk_orders[:10]:
        print(f"  {o.get('coin')}: {o.get('side')} {o.get('sz')} @ {o.get('limitPx')}")
    
    # Also check user_state for perp_dexs
    print("\n=== SDK user_state ===")
    user_state = info.user_state(MAIN)
    margin_summary = user_state.get('marginSummary', {})
    print(f"accountValue: {margin_summary.get('accountValue')}")
    print(f"totalMarginUsed: {margin_summary.get('totalMarginUsed')}")
    
    km_positions = user_state.get('assetPositions', [])
    print(f"positions: {len(km_positions)}")
    for p in km_positions:
        pos = p.get('position', {})
        print(f"  {pos.get('coin')}: size={pos.get('szi')}")

if __name__ == '__main__':
    main()
