#!/usr/bin/env python3
"""Check KM/isolated margin state for US500."""

import requests
import json

wallet = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Check perp meta to understand asset structure
print('=== PERP META (asset list) ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'meta'},
        timeout=10
    )
    data = response.json()
    # Find US500 or km assets
    universe = data.get('universe', [])
    for i, asset in enumerate(universe):
        name = asset.get('name', '')
        if 'US500' in name or 'km' in name.lower() or i < 5:
            print(f"  [{i}] {name}: {asset}")
except Exception as e:
    print(f'Error: {e}')

# Check perp clearinghouse state
print('\n=== PERP CLEARINGHOUSE STATE ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'clearinghouseState', 'user': wallet},
        timeout=10
    )
    data = response.json()
    print(json.dumps(data, indent=2))
except Exception as e:
    print(f'Error: {e}')

# Check spot clearinghouse state
print('\n=== SPOT CLEARINGHOUSE STATE ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'spotClearinghouseState', 'user': wallet},
        timeout=10
    )
    data = response.json()
    print(json.dumps(data, indent=2))
except Exception as e:
    print(f'Error: {e}')

# Check vault state (some users use vaults)
print('\n=== USER VAULTS ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'userVaults', 'user': wallet},
        timeout=10
    )
    print(f'Response: {response.text[:500]}')
except Exception as e:
    print(f'Error: {e}')

# Check if there's perp state with different endpoint
print('\n=== USER STATE (extended) ===')
try:
    response = requests.post(
        'https://api.hyperliquid.xyz/info',
        headers={'Content-Type': 'application/json'},
        json={'type': 'userState', 'user': wallet},
        timeout=10
    )
    data = response.json()
    print(json.dumps(data, indent=2))
except Exception as e:
    print(f'Error: {e}')
