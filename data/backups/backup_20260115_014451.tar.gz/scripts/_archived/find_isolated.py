#!/usr/bin/env python3
"""Try various API endpoints to find isolated margin state."""

import requests
import json

wallet = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

# Try to get isolated margin state
print('=== TRYING VARIOUS API ENDPOINTS ===')

endpoints = [
    {'type': 'userIsolatedMargin', 'user': wallet},
    {'type': 'isolatedUserState', 'user': wallet},
    {'type': 'userStateByDeployer', 'user': wallet, 'deployer': 'km'},
    {'type': 'perpUserState', 'user': wallet},
    {'type': 'perpUserStateByDeployer', 'user': wallet, 'deployer': 'km'},
    {'type': 'userPerpState', 'user': wallet, 'perpDex': 'km'},
]

for ep in endpoints:
    try:
        response = requests.post(
            'https://api.hyperliquid.xyz/info',
            headers={'Content-Type': 'application/json'},
            json=ep,
            timeout=10
        )
        print(f'{ep["type"]}: {response.status_code}')
        if response.status_code == 200:
            print(f'  {response.text[:500]}')
    except Exception as e:
        print(f'{ep["type"]}: Error - {e}')

# Check the SDK Info class methods
print('\n=== SDK INFO METHODS ===')
from hyperliquid.info import Info
from hyperliquid.utils import constants

info = Info(constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])

# Check what methods are available
methods = [m for m in dir(info) if not m.startswith('_')]
print(f'Available methods: {methods}')

# Try some methods
print('\n=== TRYING SDK METHODS ===')

# Check if there's a way to query positions directly
try:
    # Try getting metas for perp_dex
    print('perp_metas:')
    metas = info.post('/info', {'type': 'metaAndAssetCtxs'})
    if metas:
        print(f'  Meta count: {len(metas) if isinstance(metas, list) else "dict"}')
        if isinstance(metas, list) and len(metas) > 1:
            # Second element might be KM metas
            print(f'  First element type: {type(metas[0])}')
            if len(metas) > 1:
                print(f'  Second element type: {type(metas[1])}')
except Exception as e:
    print(f'Error: {e}')
