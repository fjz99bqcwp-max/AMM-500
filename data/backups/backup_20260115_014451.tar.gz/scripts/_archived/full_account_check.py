#!/usr/bin/env python3
"""Full account check for km:US500 trading - USDH isolated margin."""

import sys
sys.path.insert(0, "/Users/nheosdisplay/VSC/AMM/AMM-500")

from hyperliquid.info import Info
from hyperliquid.utils import constants as hl_constants

WALLET = "0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C"

print("=" * 70)
print("FULL ACCOUNT CHECK - km:US500 TRADING")
print("=" * 70)

# 1. Standard info (no perp_dexs) - shows cross-margin USDC
print("\n--- 1. Standard Perp State (cross-margin USDC) ---")
info_std = Info(hl_constants.MAINNET_API_URL, skip_ws=True)
std_state = info_std.user_state(WALLET)
std_margin = std_state.get("marginSummary", {})
print(f"Cross-margin Account Value: ${float(std_margin.get('accountValue', 0)):.4f}")
print(f"Cross-margin Withdrawable: ${float(std_margin.get('withdrawable', 0)):.4f}")

# Check open orders (standard)
std_orders = info_std.open_orders(WALLET)
print(f"Standard open orders: {len(std_orders)}")

# 2. km perp_dexs info - shows km:US500 positions
print("\n--- 2. HIP-3 (km) Perp State ---")
info_km = Info(hl_constants.MAINNET_API_URL, skip_ws=True, perp_dexs=['km'])
km_state = info_km.user_state(WALLET)
km_margin = km_state.get("marginSummary", {})
print(f"KM Account Value: ${float(km_margin.get('accountValue', 0)):.4f}")
print(f"KM Total Margin Used: ${float(km_margin.get('totalMarginUsed', 0)):.4f}")
print(f"KM Withdrawable: ${float(km_margin.get('withdrawable', 0)):.4f}")

# km positions
km_positions = km_state.get("assetPositions", [])
print(f"\nKM Positions ({len(km_positions)}):")
for p in km_positions:
    pos = p.get("position", {})
    size = float(pos.get("szi", 0))
    if size != 0:
        coin = pos.get("coin", "?")
        entry = float(pos.get("entryPx", 0))
        margin = float(pos.get("marginUsed", 0))
        upnl = float(pos.get("unrealizedPnl", 0))
        lev = pos.get("leverage", {})
        print(f"  {coin}: size={size:.4f}, entry=${entry:.2f}, margin=${margin:.2f}, uPnL=${upnl:.2f}, lev={lev}")

# km open orders
km_orders = info_km.open_orders(WALLET)
print(f"\nKM Open Orders ({len(km_orders)}):")
by_coin = {}
for o in km_orders:
    coin = o.get("coin", "?")
    by_coin[coin] = by_coin.get(coin, 0) + 1
for coin, count in sorted(by_coin.items(), key=lambda x: -x[1])[:10]:
    print(f"  {coin}: {count} orders")

# Show some sample orders
if km_orders:
    print("\nSample orders:")
    for o in km_orders[:5]:
        print(f"  {o.get('coin')}: {o.get('side')} {o.get('sz')} @ {o.get('limitPx')} (oid={o.get('oid')})")

# 3. Spot USDH balance
print("\n--- 3. Spot USDH Balance (margin for km:US500) ---")
spot_state = info_std.spot_user_state(WALLET)
for b in spot_state.get("balances", []):
    if b.get("coin") == "USDH":
        total = float(b.get("total", 0))
        hold = float(b.get("hold", 0))
        avail = total - hold
        print(f"USDH Total: ${total:.2f}")
        print(f"USDH Hold: ${hold:.2f}")
        print(f"USDH Available: ${avail:.2f}")
        break
else:
    print("No USDH balance found!")

# 4. Recent fills
print("\n--- 4. Recent km:US500 Fills (last 24h) ---")
import time
now = int(time.time() * 1000)
day_ago = now - (24 * 60 * 60 * 1000)
fills = info_km.user_fills_by_time(WALLET, day_ago, now)
km_fills = [f for f in fills if "km:" in f.get("coin", "")]
print(f"km:US500 fills in last 24h: {len(km_fills)}")

if km_fills:
    # Calculate PnL
    total_pnl = sum(float(f.get("closedPnl", 0)) for f in km_fills)
    total_fee = sum(float(f.get("fee", 0)) for f in km_fills)
    print(f"Total closed PnL: ${total_pnl:.2f}")
    print(f"Total fees: ${total_fee:.2f}")
    print(f"Net: ${total_pnl - total_fee:.2f}")

# Summary
print("\n" + "=" * 70)
print("SUMMARY - EQUITY FOR km:US500 TRADING")
print("=" * 70)

# For km:US500 isolated margin, the equity is:
# - Spot USDH (available for new positions)
# - Plus margin already in positions (managed by exchange)
spot_usdh = 0
for b in spot_state.get("balances", []):
    if b.get("coin") == "USDH":
        spot_usdh = float(b.get("total", 0))
        break

km_margin_used = float(km_margin.get("totalMarginUsed", 0))
km_upnl = float(km_margin.get("totalUnrealizedPnl", 0)) if "totalUnrealizedPnl" in km_margin else 0

print(f"Spot USDH: ${spot_usdh:.2f}")
print(f"KM Margin Used: ${km_margin_used:.2f}")
print(f"KM Unrealized PnL: ${km_upnl:.2f}")
print(f"TOTAL TRADING EQUITY: ${spot_usdh + km_margin_used + km_upnl:.2f}")
print(f"\nOpen Orders: {len(km_orders)}")
