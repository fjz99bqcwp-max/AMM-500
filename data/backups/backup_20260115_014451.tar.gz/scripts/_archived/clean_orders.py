#!/usr/bin/env python3
"""Script to analyze and clean all km:US500 orders."""
import os
import sys
import requests
from collections import defaultdict

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

WALLET = '0x1cCC14E273DEF02EF2BF62B9bb6B6cAa15805f9C'

def get_historical_orders():
    """Get all historical orders from API."""
    resp = requests.post(
        'https://api.hyperliquid.xyz/info',
        json={'type': 'historicalOrders', 'user': WALLET},
        timeout=60
    )
    return resp.json()

def analyze_orders():
    """Analyze km:US500 orders and find actually open ones."""
    orders = get_historical_orders()
    
    # Filter to km:US500 only
    km_orders = [o for o in orders if o.get('order', {}).get('coin') == 'km:US500']
    print(f"Total km:US500 historical records: {len(km_orders)}")
    
    # Group by OID
    by_oid = defaultdict(list)
    for o in km_orders:
        oid = o.get('order', {}).get('oid')
        by_oid[oid].append(o)
    
    print(f"Unique OIDs: {len(by_oid)}")
    
    # Find orders with latest status = open
    open_orders = []
    for oid, records in by_oid.items():
        # Sort by statusTimestamp to get latest status
        records.sort(key=lambda x: x.get('statusTimestamp', 0), reverse=True)
        latest = records[0]
        if latest.get('status') == 'open':
            open_orders.append({
                'oid': oid,
                'coin': latest.get('order', {}).get('coin'),
                'side': latest.get('order', {}).get('side'),
                'price': latest.get('order', {}).get('limitPx'),
                'size': latest.get('order', {}).get('sz'),
                'timestamp': latest.get('statusTimestamp')
            })
    
    print(f"Actually OPEN orders (by latest status): {len(open_orders)}")
    
    # Count statuses
    status_counts = defaultdict(int)
    for o in km_orders:
        status_counts[o.get('status')] += 1
    print(f"\nStatus distribution: {dict(status_counts)}")
    
    return open_orders

def cancel_all_orders():
    """Cancel all open km:US500 orders using SDK."""
    from dotenv import load_dotenv
    load_dotenv('config/.env')
    
    from eth_account import Account
    from hyperliquid.exchange import Exchange
    from hyperliquid.info import Info
    
    # Get credentials
    private_key = os.getenv('WALLET_PRIVATE_KEY') or os.getenv('API_WALLET_PRIVATE_KEY')
    if not private_key:
        print("ERROR: No private key found in environment")
        return
    
    account = Account.from_key(private_key)
    print(f"Using wallet: {account.address}")
    
    # Create exchange client
    exchange = Exchange(account, 'https://api.hyperliquid.xyz', account_address=WALLET)
    
    # Get open orders
    open_orders = analyze_orders()
    
    if not open_orders:
        print("\nNo open orders to cancel!")
        return
    
    print(f"\nCancelling {len(open_orders)} orders...")
    
    # Build cancel list
    cancels = [
        {'coin': o['coin'], 'oid': o['oid']} 
        for o in open_orders
    ]
    
    # Cancel in batches of 50
    batch_size = 50
    cancelled = 0
    for i in range(0, len(cancels), batch_size):
        batch = cancels[i:i+batch_size]
        try:
            result = exchange.bulk_cancel(batch)
            if result.get('status') == 'ok':
                statuses = result.get('response', {}).get('data', {}).get('statuses', [])
                success_count = sum(1 for s in statuses if s.get('filled') or 'success' in str(s).lower())
                cancelled += success_count
                print(f"  Batch {i//batch_size + 1}: {len(batch)} orders, {success_count} cancelled")
            else:
                print(f"  Batch {i//batch_size + 1}: Error - {result}")
        except Exception as e:
            print(f"  Batch {i//batch_size + 1}: Exception - {e}")
    
    print(f"\nTotal cancelled: {cancelled}/{len(open_orders)}")
    
    # Verify
    print("\nVerifying...")
    remaining = analyze_orders()
    print(f"Remaining open orders: {len(remaining)}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--cancel':
        cancel_all_orders()
    else:
        analyze_orders()
        print("\nRun with --cancel to cancel all orders")
