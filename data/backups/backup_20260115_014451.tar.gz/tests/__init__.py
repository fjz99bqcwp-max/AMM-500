"""
Tests Package
Unit tests for the HFT bot.
"""
